

export const menu = () => {
	var replaceableContainer = document.createElement('div')

	replaceableContainer.id = 'replaceableContainer'
	replaceableContainer.className = 'replaceable-container'

	


	return replaceableContainer
}